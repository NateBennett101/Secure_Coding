// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value: ";
    // This should use std::cin.getline to read the input which should take the buffer, size, and delimiter as arguments.
    // This should prevent the user from entering more characters than the buffer can hold, thus avoiding buffer overflow.
    std::cin.getline(user_input, sizeof(user_input));

    // This should check if the user enters a string longer than the buffer, if so, std::cin should go into an error state.
    if (!std::cin) {
        // This should clear the error flags.
        std::cin.clear();
        // This should ignore the rest of the input until the next newline.
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
