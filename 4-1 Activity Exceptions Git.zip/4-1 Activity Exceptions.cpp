// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

class CustomException : public std::exception
{
    public:
      // This should be a constructor with a default error message.
      CustomException() noexcept : msg("Custom Exception: Error in application logic.") {}
    
      // This should override what() to return a custom error message.
      const char* what() const noexcept override
      {
        return msg.c_str();
      }
    
    private:
      std::string msg;
};

bool do_even_more_custom_application_logic()
{
  // This should throw a standard exception runtime_error.
  throw std::runtime_error("Standard Exception: Failure in even more custom logic.");

  std::cout << "Running Even More Custom Application Logic." << std::endl;
  return true;
}

void do_custom_application_logic()
{
  std::cout << "Running Custom Application Logic." << std::endl;

  try
  {
    if(do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception& e)
  {
    // This should catch standard exceptions.
    std::cout << "Exception Caught: " << e.what() << std::endl;
  }
  
  throw CustomException();

  std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
  // This should throw an exception for divide by zero errors.
  if(den == 0) throw std::domain_error("Error: Division by zero.");
  return (num / den);
}

void do_division() noexcept
{
  try
  {
    float numerator = 10.0f;
    float denominator = 0;
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::exception& e)
  {
    std::cout << "Exception in division: " << e.what() << std::endl;
  }
}

int main()
{
  try
  {
    do_division();
    do_custom_application_logic();
  }
  // This should catch custom exceptions first.
  catch (const CustomException& e)
  {
    std::cout << "Custom Exception Caught: " << e.what() << std::endl;
  }
  // This should catch standard exceptions.
  catch (const std::exception& e)
  {
    std::cout << "Standard Exception Caught: " << e.what() << std::endl;
  }
  // This should catch any other unhandled exceptions.
  catch (...)
  {
    std::cout << "Unknown Exception Caught" << std::endl;
  }

  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu